console.log("vamos começar a mexer com o Node Js e entender como ele se comporta");
