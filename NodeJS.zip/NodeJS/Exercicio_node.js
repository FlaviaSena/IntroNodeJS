const prompt = require('prompt-sync'); // Modulo do node necessário para utilizar o nodeJS
const entrada = prompt();
//O renato me passou que nesse caso aqui  a cima a const Entrada recebeu o prompt como um Objeto 

//
var nome =entrada("Por favor me informe o seu nome?");
var n1 = Number(entrada(" Por favor me informe os números para que eu faça a media de suas notas para você! "));
var n2 = Number(entrada(" Por favor me informe os números para que eu faça a media de suas notas para você! "));
var n3 = Number(entrada(" Por favor me informe os números para que eu faça a media de suas notas para você! "));
var n4 = Number(entrada(" Por favor me informe os números para que eu faça a media de suas notas para você! "));

var media = ((n1+n2+n3+n4) / 4)


if(media>=7){
    console.log(media + "Você está mais que aprovado para passar de ano Parabens!!!");

}else if(media<7){
    
    console.log("Você vai precisar fazer recuperação!");
    var recupera = Number(entrada(" Por favor me informe o da sua recuperação "));
    var  novamedia = ((media+recupera) / 2);
    if(novamedia>=6){
        console.log( novamedia+"\n" + "Você está mais que aprovado para passar de ano Parabens apos a sua recuperação!!!");
    }else{
        console.log("Sua média é de: "+novamedia+"\n"+ "Você foi reprovado amiga (o)! ");
    }

}












    