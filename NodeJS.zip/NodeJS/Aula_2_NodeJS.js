const prompt = require('prompt-sync');
const entrada = prompt();
var nome = entrada("Por favor me informe o seu nome:");
console.log("Olá, "+ nome);